<?php

use App\Http\Controllers\CommentController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::view('/', 'home');

Route::group(['middleware' => ['auth']], function () {
    Route::get('/dashboard', [HomeController::class, 'homePage'])->name('dashboard');

    Route::get('/read/{post:slug}', [HomeController::class, 'readPost'])->name('post.read');

    Route::group(['prefix' => 'comment'], function () {
        Route::post('/store', [CommentController::class, 'store'])->name('comment.store');
    });
});

Route::group(['prefix' => 'admin', 'middleware' => ['auth','can:access admin dashboard'], 'as' => 'admin.'], function () {
    Route::get('/', [AdminController::class, 'dashboard'])->name('dashboard');
    Route::group(['prefix' => 'users', 'as' => 'users.', 'middleware' => 'can:access admin users'], function () {
        Route::get('/', [UserController::class, 'index'])->name('index');
        Route::get('/create', [UserController::class, 'create'])->name('create')->middleware('can:create users');
        Route::post('/create', [UserController::class, 'store'])->name('store')->middleware('can:create users');
        Route::delete('/{user}', [UserController::class, 'destroy'])->name('delete')->middleware('can:delete users');
        Route::get('/{user}/edit', [UserController::class, 'edit'])->name('edit')->middleware('can:update users');
        Route::post('/{user}/edit', [UserController::class, 'update'])->name('update')->middleware('can:update users');
    });
    Route::group(['prefix' => 'posts', 'as' => 'posts.', 'middleware' => 'can:access admin posts'], function () {
        Route::get('/', [PostController::class, 'index'])->name('index');
        Route::get('/create', [PostController::class, 'create'])->name('create')->middleware('can:create posts');
        Route::post('/create', [PostController::class, 'store'])->name('store')->middleware('can:create posts');
        Route::delete('/{post}', [PostController::class, 'destroy'])->name('delete')->middleware('can:delete posts');
        Route::get('/{post}/edit', [PostController::class, 'edit'])->name('edit')->middleware('can:update posts');
        Route::post('/{post}/edit', [PostController::class, 'update'])->name('update')->middleware('can:update posts');
    });
    Route::group(['prefix' => 'categories', 'as' => 'categories.', 'middleware' => 'can:access admin categories'], function () {
        Route::get('/', [CategoryController::class, 'index'])->name('index');
        Route::get('/create', [CategoryController::class, 'create'])->name('create')->middleware('can:create categories');
        Route::post('/create', [CategoryController::class, 'store'])->name('store')->middleware('can:create categories');
        Route::delete('/{category}', [CategoryController::class, 'destroy'])->name('delete')->middleware('can:delete categories');
        Route::get('/{category}/edit', [CategoryController::class, 'edit'])->name('edit')->middleware('can:update categories');
        Route::post('/{category}/edit', [CategoryController::class, 'update'])->name('update')->middleware('can:update categories');
    });
    Route::group(['prefix' => 'roles', 'as' => 'roles.', 'middleware' => 'can:access admin roles'], function () {
        Route::get('/', [RoleController::class, 'index'])->name('index');
        Route::get('/create', [RoleController::class, 'create'])->name('create')->middleware('can:create roles');;
        Route::post('/create', [RoleController::class, 'store'])->name('store')->middleware('can:create roles');;
        Route::delete('/{role}', [RoleController::class, 'destroy'])->name('delete')->middleware('can:delete roles');;
        Route::get('/{role}/edit', [RoleController::class, 'edit'])->name('edit')->middleware('can:update roles');;
        Route::post('/{role}/edit', [RoleController::class, 'update'])->name('update')->middleware('can:update roles');;
    });
});

