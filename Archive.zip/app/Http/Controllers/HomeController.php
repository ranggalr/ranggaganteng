<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Inertia\Inertia;

class HomeController extends Controller
{
    public function homePage()
    {
        return Inertia::render('Dashboard', [
            'posts' => Post::with(['category','user'])->paginate(10)
        ]);
    }

    public function readPost(Post $post)
    {
        return Inertia::render('ViewPost', [
            'post' => $post,
            'user' => $post->user,
            'category' => $post->category,
            'comments' => $post->comments()->with('user')->orderBy('created_at','desc')->paginate(15),
        ]);
    }
}
